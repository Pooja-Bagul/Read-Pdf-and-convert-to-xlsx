import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;


import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



import java.util.*;
import java.io.*;
import java.io.File;
import java.io.IOException;
public class ReadPdf3 
{
	public static void main(String args[]) throws IOException 
	{
		try
		{
			
			
						
			String excelFileName = "data.xlsx";//name of excel file

			String sheetName = "Sheet1";//name of sheet

			XSSFWorkbook wb = new XSSFWorkbook();
			XSSFSheet sheet = wb.createSheet(sheetName) ;
			XSSFCell cell= null;
			int r=0;
			int c=0;
			
			PDDocument document = PDDocument.load(new File("file2.pdf"));// here file1.pdf is the name of pdf file which we want to read....
			document.getClass();
			if (!document.isEncrypted())
			{
				PDFTextStripperByArea stripper = new PDFTextStripperByArea();
				stripper.setSortByPosition(true);
				PDFTextStripper Tstripper = new PDFTextStripper();
				String str = Tstripper.getText(document);
				
				Scanner scnLine = null;					
				scnLine = new Scanner(str);
				
				
				
				String line="";
				String strDate="";
				String strDay="";
				String strTotalProfit="";
				String strDailyProfit="";
				
				while (scnLine.hasNextLine()) 
				{		
					
					
					c=0;
					line = scnLine.nextLine();
					XSSFRow row = sheet.createRow(r);
					
					Scanner scnWord = new Scanner(line);	
					
					strDate=scnWord.next();
					cell = row.createCell(c);
					cell.setCellValue(strDate);
					c++;
							
					
					strDay=scnWord.next();
					cell = row.createCell(c);
					cell.setCellValue(strDay);
					c++;
					
					
					strTotalProfit=scnWord.next();
					cell = row.createCell(c);
					cell.setCellValue(strTotalProfit);
					c++;
					
					
					strDailyProfit=scnWord.next();
					cell = row.createCell(c);
					cell.setCellValue(strDailyProfit);
					c++;
					
					r++;
					
				}	
			}
			
			
			FileOutputStream fileOut = new FileOutputStream(excelFileName);

			//write this workbook to an Outputstream.
			wb.write(fileOut);
			fileOut.flush();
			fileOut.close();
			
			
			document.close();
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
			
	}

	

}